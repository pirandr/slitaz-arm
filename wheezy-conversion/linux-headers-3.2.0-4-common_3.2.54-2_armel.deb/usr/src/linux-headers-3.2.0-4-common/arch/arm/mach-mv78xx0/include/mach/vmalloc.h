/*
 * arch/arm/mach-mv78xx0/include/mach/vmalloc.h
 */

#define VMALLOC_END	0xfe000000UL
