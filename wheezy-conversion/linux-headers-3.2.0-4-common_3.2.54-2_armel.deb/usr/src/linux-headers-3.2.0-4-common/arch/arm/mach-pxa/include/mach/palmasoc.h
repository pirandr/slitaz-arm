#ifndef _INCLUDE_PALMASOC_H_
#define _INCLUDE_PALMASOC_H_

struct palm27x_asoc_info {
	int	jack_gpio;
};

#endif
