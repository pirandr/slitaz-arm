#ifndef __MACH_DMA_MX1_MX2_H__
#define __MACH_DMA_MX1_MX2_H__
/*
 * Don't use this header in new code, it will go away when all users are
 * converted to mach/dma-v1.h
 */

#include <mach/dma-v1.h>

#endif /* ifndef __MACH_DMA_MX1_MX2_H__ */
