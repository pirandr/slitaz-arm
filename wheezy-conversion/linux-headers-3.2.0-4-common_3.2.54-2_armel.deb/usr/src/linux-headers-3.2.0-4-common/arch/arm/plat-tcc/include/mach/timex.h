/*
 * A definition needed by arch core code.
 *
 */
#define CLOCK_TICK_RATE		(HZ * 100000UL)
