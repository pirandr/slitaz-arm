/*
 * Author: <linux@telechips.com>
 * Created: June 10, 2008
 *
 * Copyright (C) 2000 Russell King.
 * Copyright (C) 2008-2009 Telechips
 *
 * Licensed under the terms of the GPL v2.
 */
#define VMALLOC_END	0xf0000000UL
