/*
 * Cavium Networks architecture timex specifications
 *
 * Copyright 2003 ARM Limited
 * Copyright 2008 Cavium Networks
 *
 * This file is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, Version 2, as
 * published by the Free Software Foundation.
 */

#define CLOCK_TICK_RATE		(50000000 / 16)
