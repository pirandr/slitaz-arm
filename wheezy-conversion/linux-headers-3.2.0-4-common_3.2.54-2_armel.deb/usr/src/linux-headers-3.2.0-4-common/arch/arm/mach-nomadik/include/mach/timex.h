#ifndef __ASM_ARCH_TIMEX_H
#define __ASM_ARCH_TIMEX_H

#define CLOCK_TICK_RATE         2400000

#endif
