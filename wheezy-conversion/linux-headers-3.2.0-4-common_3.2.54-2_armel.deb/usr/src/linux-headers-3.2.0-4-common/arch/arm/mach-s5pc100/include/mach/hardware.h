/* linux/arch/arm/mach-s5pc100/include/mach/hardware.h
 *
 * Copyright 2009 Samsung Electronics Co.
 *      Byungho Min <bhmin@samsung.com>
 *
 * S5PC100 - Hardware support
 */

#ifndef __ASM_ARCH_HARDWARE_H
#define __ASM_ARCH_HARDWARE_H __FILE__

/* currently nothing here, placeholder */

#endif /* __ASM_ARCH_HARDWARE_H */
