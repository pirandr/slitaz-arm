/*
 * arch/arm/mach-omap2/include/mach/hardware.h
 */

#include <plat/hardware.h>
