/*
 * arch/arm/mach-omap2/include/mach/system.h
 */

#include <plat/system.h>
