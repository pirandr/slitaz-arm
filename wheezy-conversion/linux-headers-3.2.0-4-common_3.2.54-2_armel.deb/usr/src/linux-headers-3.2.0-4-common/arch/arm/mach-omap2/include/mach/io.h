/*
 * arch/arm/mach-omap2/include/mach/io.h
 */

#include <plat/io.h>
