/*
 * arch/arm/mach-omap2/include/mach/smp.h
 */

#include <plat/smp.h>
