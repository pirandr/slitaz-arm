#ifndef __ASM_MACH_VMALLOC_H
#define __ASM_MACH_VMALLOC_H

/* Vmalloc at ... - 0xe5ffffff */
#define VMALLOC_END 0xe6000000UL

#endif /* __ASM_MACH_VMALLOC_H */
