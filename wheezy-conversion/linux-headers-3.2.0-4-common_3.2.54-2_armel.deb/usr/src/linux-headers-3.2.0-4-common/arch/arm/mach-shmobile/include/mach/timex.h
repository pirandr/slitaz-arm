#ifndef __ASM_MACH_TIMEX_H
#define __ASM_MACH_TIMEX_H

#define CLOCK_TICK_RATE		1193180 /* unused i8253 PIT value */

#endif /* __ASM_MACH_TIMEX_H */
