/*
 * arch/arm/mach-shark/include/mach/vmalloc.h
 */
#define VMALLOC_END       0xd0000000UL
