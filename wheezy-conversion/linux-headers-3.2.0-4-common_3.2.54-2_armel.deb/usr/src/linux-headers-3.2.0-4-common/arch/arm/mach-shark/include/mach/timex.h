/*
 * arch/arm/mach-shark/include/mach/timex.h
 *
 * by Alexander Schulz
 */

#define CLOCK_TICK_RATE 1193180
