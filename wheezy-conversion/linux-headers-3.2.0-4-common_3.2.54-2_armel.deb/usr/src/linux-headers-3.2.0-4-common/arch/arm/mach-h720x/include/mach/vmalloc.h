/*
 * arch/arm/mach-h720x/include/mach/vmalloc.h
 */

#ifndef __ARCH_ARM_VMALLOC_H
#define __ARCH_ARM_VMALLOC_H

#define VMALLOC_END       0xd0000000UL

#endif
