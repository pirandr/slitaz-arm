/*
 * arch/arm/mach-ixp23xx/include/mach/timex.h
 *
 * XScale architecture timex specifications
 */

#define CLOCK_TICK_RATE 75000000
