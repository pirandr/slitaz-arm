/*
 * arch/arm/mach-ixp23xx/include/mach/time.h
 */
