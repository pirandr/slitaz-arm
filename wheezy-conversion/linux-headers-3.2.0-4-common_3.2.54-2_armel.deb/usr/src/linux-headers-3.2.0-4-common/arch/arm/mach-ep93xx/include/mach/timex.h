/*
 * arch/arm/mach-ep93xx/include/mach/timex.h
 */

#define CLOCK_TICK_RATE		983040
