/*
 * arch/arm/mach-ep93xx/include/mach/vmalloc.h
 */

#define VMALLOC_END	0xfe800000UL
