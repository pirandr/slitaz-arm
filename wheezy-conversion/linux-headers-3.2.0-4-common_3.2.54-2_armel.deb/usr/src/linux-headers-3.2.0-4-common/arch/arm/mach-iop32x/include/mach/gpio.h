#ifndef __ASM_ARCH_IOP32X_GPIO_H
#define __ASM_ARCH_IOP32X_GPIO_H

#include <asm/hardware/iop3xx-gpio.h>

#endif
