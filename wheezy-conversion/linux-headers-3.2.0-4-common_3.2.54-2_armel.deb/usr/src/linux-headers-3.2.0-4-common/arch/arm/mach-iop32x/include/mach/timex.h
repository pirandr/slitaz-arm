/*
 * arch/arm/mach-iop32x/include/mach/timex.h
 *
 * IOP32x architecture timex specifications
 */
#define CLOCK_TICK_RATE		(100 * HZ)
