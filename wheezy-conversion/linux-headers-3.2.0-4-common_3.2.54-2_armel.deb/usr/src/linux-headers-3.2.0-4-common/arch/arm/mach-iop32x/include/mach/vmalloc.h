/*
 * arch/arm/mach-iop32x/include/mach/vmalloc.h
 */

#define VMALLOC_END	0xfe000000UL
