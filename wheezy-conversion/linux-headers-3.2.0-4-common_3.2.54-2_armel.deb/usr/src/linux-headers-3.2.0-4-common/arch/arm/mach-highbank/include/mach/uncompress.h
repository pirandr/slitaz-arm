#ifndef __MACH_UNCOMPRESS_H
#define __MACH_UNCOMPRESS_H

#define putc(c)
#define flush()
#define arch_decomp_setup()
#define arch_decomp_wdog()

#endif
