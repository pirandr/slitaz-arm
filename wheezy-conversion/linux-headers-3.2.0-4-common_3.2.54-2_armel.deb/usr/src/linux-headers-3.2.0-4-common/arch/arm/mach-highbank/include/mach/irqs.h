#ifndef __MACH_IRQS_H
#define __MACH_IRQS_H

#define NR_IRQS			192

#endif
