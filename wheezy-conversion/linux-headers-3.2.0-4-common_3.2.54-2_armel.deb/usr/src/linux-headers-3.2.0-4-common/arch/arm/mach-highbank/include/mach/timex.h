#ifndef __MACH_TIMEX_H
#define __MACH_TIMEX_H

#define CLOCK_TICK_RATE		1000000

#endif
